// -----------------------------------------------------------------------------
// rgw-utils.js
//
// Landing page for RGW related utils.
// -----------------------------------------------------------------------------

Polymer({
    is: 'rgw-utils',

    ready: function() {
        console.log(this.is + ": ready()");
    }
});
